# CoreX Terminal — native Rust shell (2.0.0)

`corex` is a native Linux desktop shell for the CoreX web terminal
(<https://corex-2hl.pages.dev/>). Version 2.0.0 replaces the Electron shell
with a ~1 MB Rust binary on WebKitGTK (wry + tao): same window, same URL,
same behaviours — a fraction of the RAM.

## Measured RAM (peak process-tree RSS, page fully loaded, Xvfb 1280×800)

The same harness sampled `/proc/<pid>/status` VmRSS across the whole process
tree every 1.5 s for ~14 s, for both shells loading the same page:

| Shell                  | Run 1      | Run 2      | Processes |
|------------------------|-----------:|-----------:|----------:|
| Electron 45 (Chromium) | 717 MB     | 730 MB     | 6         |
| **Rust + WebKitGTK**   | **383 MB** | **388 MB** | **3**     |

**≈ 47 % less RAM**, one small binary instead of a bundled Chromium.
Note the method sums VmRSS per process, which double-counts shared pages —
identically for both shells, so the comparison is fair.

## Install

```sh
sudo apt install ./corex_2.0.0_amd64.deb
```

Runtime dependencies (pulled in by apt on Debian 12+/Ubuntu 22.04+):
`libgtk-3-0t64 | libgtk-3-0`, `libwebkit2gtk-4.1-0`, `libsoup-3.0-0`.

## Use

- Launch from the application menu ("CoreX Terminal") or run `corex`.
- `corex <url>` loads an arbitrary URL instead (handy for local testing,
  e.g. `corex http://localhost:8000`).
- `corex --smoke` runs 9 s, prints the process-tree RSS (`SMOKE_RSS_KB …`)
  and the actual window title (`SMOKE_WINDOW_TITLE …`), then exits — used
  for the measurements and title checks above.

### Behaviours (parity with the Electron 1.x shell)

- Loads the terminal from `https://corex-2hl.pages.dev/`.
- **One title rule**: the window title bar always shows "CoreX Terminal".
  The web page keeps its own dynamic header and per-page `<title>` inside
  the webview, but the page title is never shown in or appended to the
  app's title bar. (The old Electron shell followed the page title — e.g.
  "CoreX — Live Market Charts"; the Rust shell never does, and re-asserts
  its own title on every completed page load.)
- **Navigation guard**: only CoreX hosts (`corex-2hl.pages.dev`,
  `*.pages.dev`) may navigate; external links open in the system browser.
- **State persistence**: cookies + localStorage live under
  `$XDG_DATA_HOME/corex` (default `~/.local/share/corex`), so logins and
  panel settings survive restarts.
- **Single instance**: a second `corex` launch is a no-op (flock in
  `$XDG_RUNTIME_DIR`).
- **Offline page**: if the site is unreachable at startup, an inline page
  is shown with auto-retry every 4 s and a manual *Retry now* button.

## Build from source

```sh
cargo build --release      # needs libwebkit2gtk-4.1-dev + libgtk-3-dev + libsoup-3.0-dev
```

Requires rustc ≥ 1.88 (the committed `Cargo.lock` resolves ICU 2.4.x
crates whose MSRV is 1.88 — e.g. Debian 13's rustc 1.85.1 is rejected by
cargo); use rustup on distros that ship older rustc. `cargo check` with
the lock pins `tao 0.30.8` / `wry 0.45.0`.

The `.deb` in this delivery was assembled by hand
(`dpkg-deb --root-owner-group`): control metadata, `.desktop` entry,
hicolor icons from the site logo, copyright file.

## Packaging

`corex_2.0.0_amd64.deb` — 474 KB installed archive, 1.3 MB installed size
(the Electron deb shipped a full Chromium runtime). Window icon comes from
`assets/corex-192.png`; `StartupWMClass=corex` matches the WM_CLASS GDK
derives from the binary name, so the taskbar icon and grouping work.
